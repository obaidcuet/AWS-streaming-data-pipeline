from __future__ import print_function

import base64
import re
import json
import time

print('Loading function')

def lambda_handler(event, context):
    output = []
    record_cnt = 0

    for record in event['records']:
        #print(record['recordId'])
        input_payload = json.loads(base64.b64decode(record['data']))

        record_cnt += 1
        output_payload = str(input_payload['id'])+','+ str(input_payload['type'])+','+str(input_payload['wiki'])+','+time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(input_payload['timestamp']))+','+str(input_payload['timestamp'])+'\n'
                         
        output_record = {
            'recordId': record['recordId'],
            'result': 'Ok',
            'data': base64.b64encode(output_payload)
        }
		
        output.append(output_record)

    print('Processing completed {} records'.format(record_cnt))
    return {'records': output}
