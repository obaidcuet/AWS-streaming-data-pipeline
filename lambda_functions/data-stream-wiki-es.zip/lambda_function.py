from __future__ import print_function

import base64
import re
import json
import time

print('Loading function')

def lambda_handler(event, context):
    output = []
    record_cnt = 0

    for record in event['records']:
        input_payload = json.loads(base64.b64decode(record['data']))

        record_cnt += 1

        output_payload = {
                            'id': str(input_payload['id']),
                            'type': str(input_payload['type']),
                            'wiki': str(input_payload['wiki']),
                            'change_datetime': time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(input_payload['timestamp'])),
                            'change_timestamp': input_payload['timestamp']
				         }
                		
        output_record = {
            'recordId': record['recordId'],
            'result': 'Ok',
            'data': base64.b64encode(json.dumps(output_payload))
        }
		
        output.append(output_record)

    print('Processing completed {} records'.format(record_cnt))
    return {'records': output}
    
